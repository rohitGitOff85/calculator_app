class CalculatorController < ApplicationController
  def home
  end

  def calculate
    @numbers = params[:numbers]
    begin
		session[:result] = StringCalculator.add(@numbers)
    rescue Exception => e
      @error = e.message
    end
    redirect_to request.referer 
  end
end