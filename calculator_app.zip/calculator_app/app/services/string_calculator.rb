# app/services/string_calculator.rb
class StringCalculator
  def self.add(numbers)
    # Return 0 if the input is empty or nil
    return 0 if numbers.blank?

    # Default delimiters are comma (,) or newline (\n)
    delimiter = /,|\n/

    # Check for a custom delimiter defined by the format: "//[delimiter]\n[numbers]"
    if numbers.start_with?("//")
      # Split the input into the delimiter definition and the actual numbers string
      delimiter_line, numbers = numbers.split("\n", 2)

      # Extract the custom delimiter from the prefix (e.g., "//;\n1;2" => ";")
      custom_delim = delimiter_line[2..]  # Removes the "//" prefix

      # Escape the custom delimiter to make it regex-safe
      delimiter = Regexp.escape(custom_delim)
    end

    # Split the numbers string using the determined delimiter(s), and convert each to an integer
    nums = numbers.split(/#{delimiter}/).map(&:to_i)

    # Find all negative numbers
    negatives = nums.select { |n| n < 0 }

    # If there are any negative numbers, raise an error listing all of them
    if negatives.any?
      raise ArgumentError, "negative numbers not allowed: #{negatives.join(',')}"
    end

    nums.sum
  end
end